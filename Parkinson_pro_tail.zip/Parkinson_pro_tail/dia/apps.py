from django.apps import AppConfig


class DiaConfig(AppConfig):
    name = 'dia'
