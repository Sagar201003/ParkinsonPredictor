from django.apps import AppConfig


class DiaDjangoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dia_django'
