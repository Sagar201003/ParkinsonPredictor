const checkStatus = document.querySelector("#checkStatus");

function tryIt(){
    checkStatus.style.display="none";
    document.querySelector("#form").style.display="block"
}
